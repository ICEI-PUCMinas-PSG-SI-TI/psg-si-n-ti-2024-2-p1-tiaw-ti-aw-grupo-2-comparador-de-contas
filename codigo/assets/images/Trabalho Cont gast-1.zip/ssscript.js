const cotacoes = { 

    hidroeletrica: 1.0, 

    petroleo: 1.5, 

    carvao: 1.2, 

    biocombustiveis: 0.9, 

    gas_natural: 1.1, 

    nuclear: 1.3, 

    eolica: 0.8, 

    solar: 0.7 

}; 

 

document.getElementById('converterForm').addEventListener('submit', function(event) { 

    event.preventDefault(); 

 

    const valor = parseFloat(document.getElementById('valor').value); 

    const origem = document.getElementById('origem').value; 

    const destino = document.getElementById('destino').value; 

 

    if (!valor || isNaN(valor) || origem === "" || destino === "") { 

        alert("Por favor, preencha todos os campos corretamente."); 

        return; 

    } 

 

    const valorConvertido = (valor * cotacoes[destino]) / cotacoes[origem]; 

    const resultadoDiv = document.getElementById('resultado'); 

 

    resultadoDiv.innerHTML = ` 

        <strong>Resultado da Conversão:</strong><br> 

        Valor convertido: R$ ${valorConvertido.toFixed(2)}<br> 

        Cotação de ${origem.charAt(0).toUpperCase() + origem.slice(1).replace(/_/g, ' ')} para ${destino.charAt(0).toUpperCase() + destino.slice(1).replace(/_/g, ' ')}: ${(cotacoes[destino] / cotacoes[origem]).toFixed(2)}  

    `; 

}); 